package mainpackage;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class RealPolynomial {
    private int degree;
    private double[] coef;
    
    public RealPolynomial(List<Double> coef) {
        double[] coefArray = new double[coef.size()];
        for (int i = 0; i < coef.size(); i++) coefArray[i] = coef.get(i);
        coefArray = deleteLastZeros(coefArray);
        this.coef = coefArray;
        this.degree = coefArray.length - 1;
    }
    
    public RealPolynomial(double... coef) {
        coef = deleteLastZeros(coef);
        this.coef = coef;
        this.degree = coef.length - 1;
    }

    public RealPolynomial(int n) {
        this.degree = n;
        this.coef = new double[n+1];
    }
    
    public double getCoefficient(int i) {
        try {return coef[i];}
        catch (Exception e) {return Double.NaN;}
    }

    public int getDegree() {return this.degree;}
    public double[] getCoef() {return this.coef;}
    
    public boolean isZero() {return this.nonZeroIndex() == -2;}
    
    public static double[] deleteLastZeros(double[] coefArray) {
        int index = -1;
        int len = coefArray.length;
        for (int i = 0; i < len; i++) {
            if (coefArray[len - 1 - i] != 0) {
                index = i;
                break;
            }
        }
        if (index != -1) return Arrays.copyOfRange(coefArray, 0, len - index);
        else return new double[] {0.0};
    }
    
    // -2 -> All coefficients are 0, hence the zero polynomial, which can be cast to a trivial monomial
    // -1 -> More than one coefficient is nonzero, hence it can't be cast to a monomial
    // >=0 -> Exactly one coefficient, with the returned int as its index, is nonzero, so it can be cast to a monomial
    public int nonZeroIndex() {
        double[] coefArray = this.coef;
        int index = -2;
        boolean foundNonZero = false;
        for (int i = 0; i < coefArray.length; i++) {
            if (!foundNonZero && coefArray[i] != 0) {
                index = i;
                foundNonZero = true;
            } else if (foundNonZero && index != -1 && coefArray[i] != 0) index = -1;
        }
        return index;
    }
    
    public RealPolynomial castToMonomial() {
        int monomialDegree = this.nonZeroIndex();
        switch (monomialDegree) {
            case -2 -> {return new RealMonomial(0, 0);}
            case -1 -> {return this;}
            default -> {return new RealMonomial(this.getCoefficient(monomialDegree), monomialDegree);}
        }
    }
    
    public RealMonomial getMonomial(int deg) {
        try {return new RealMonomial(this.getCoefficient(deg), deg);}
        catch (Exception e) {return new RealMonomial(0, 0);}
    }
    
    public RealPolynomial sum(RealPolynomial p) {
        double[] resultCoef = new double[Math.max(this.degree, p.degree)+1];
        for (int i = 0; i < resultCoef.length; i++) {
            if (i < this.coef.length && i < p.coef.length) resultCoef[i] = this.coef[i] + p.coef[i];
            else if (i < this.coef.length && i >= p.coef.length) resultCoef[i] = this.coef[i];
            else if (i >= this.coef.length && i < p.coef.length) resultCoef[i] = p.coef[i];
        }
        return new RealPolynomial(resultCoef).castToMonomial();
    }
    
    public RealPolynomial invertSign() {
        double[] resultCoef = new double[this.degree + 1];
        for (int i = 0; i <= this.degree; i++) resultCoef[i] = -this.getCoefficient(i);
        return new RealPolynomial(resultCoef).castToMonomial();
    }
    
    public RealPolynomial rest(RealPolynomial p) {return this.sum(p.invertSign());}
    
    public RealPolynomial mult(RealPolynomial p) {
        RealPolynomial result = new RealPolynomial(0);
        for (int i = 0; i <= this.degree; i++) result = result.sum(this.getMonomial(i).mult(p));
        return result;
    }
    
    public RealPolynomial pow(int n) {
        RealPolynomial result = new RealMonomial(1);
        for (int i = 0; i < n; i++) result = result.mult(this);
        return result;
    }
    
    public RealPolynomial diff() {
        RealPolynomial result = new RealPolynomial(0);
        for (int i = 0; i <= this.degree; i++) result = result.sum(this.getMonomial(i).diff());
        return result;
    }
    
    public RealPolynomial diff(int n) {
        RealPolynomial result = this;
        for (int i = 0; i < n; i++) result = result.diff();
        return result;
    }
    
    @Override
    public String toString() {
        String str = "";
        if (this.degree == 0 && this.getCoefficient(0) == 0) return "0";
        for (int i = this.degree; i >= 0; i--) {
            String sign = "";
            double coeff = this.getCoefficient(i);
            if (i != this.degree && coeff > 0) sign = " + ";
            else if (i != this.degree && coeff < 0) sign = " - ";
            else if (i == this.degree && coeff < 0) sign = "-";
            str = str + (coeff != 0 ? sign + Math.abs(coeff) + (i != 0 ? " * x^"+i : "") : "");
        }
        return str;
    }
    
    public double evaluate(double d) {
        double result = 0;
        for (int i = 0; i <= this.degree; i++) result += this.getCoefficient(i) * Math.pow(d, i);
        return result;
    }
    
    public double NewtonRaphsonMethod(double x, double eps, int maxit, boolean printIterations) {
        int counter = 1;
        if (printIterations) {
            System.out.printf("Newton's Method applied to the polynomial: " + this + "\nWith initial value %.2f\n", x);
            System.out.println("| it\t| x\t\t| p(x)\t\t| p'(x)\t\t|");
        }
        while (Math.abs(this.evaluate(x)) > eps && counter < maxit) {
            if (printIterations) System.out.printf("| %d\t| %.6f\t| %.6f\t| %.6f\t|\n", counter, x, this.evaluate(x), this.diff().evaluate(x));
            if (this.diff().evaluate(x) != 0) x = x - this.evaluate(x)/this.diff().evaluate(x);
            else {
                if (printIterations) System.out.println("Division by zero");
                return Double.NaN;
            }
            counter++;
        }
        return x;
    }
    
    public double HalleyMethod(double x, double eps, int maxit, boolean printIterations) {
        int counter = 1;
        if (printIterations) {
            System.out.printf("Halley's Method applied to the polynomial: " + this + "\nWith initial value %.2f\n", x);
            System.out.println("| it\t| x\t\t| p(x)\t\t| p'(x)\t\t|");
        }
        while (Math.abs(this.evaluate(x)) > eps && counter < maxit) {
            if (printIterations) System.out.printf("| %d\t| %.6f\t| %.6f\t| %.6f\t|\n", counter, x, this.evaluate(x), this.diff().evaluate(x));
            if (2*Math.pow(this.diff().evaluate(x), 2) - this.evaluate(x)*this.diff(2).evaluate(x) != 0) x = x - 2*this.evaluate(x)*this.diff().evaluate(x)/(2*Math.pow(this.diff().evaluate(x), 2) - this.evaluate(x)*this.diff(2).evaluate(x));
            else {
                if (printIterations) System.out.println("Division by zero");
                return Double.NaN;
            }
            counter++;
        }
        return x;
    }
    
    public Function<Double, Double> toFunction() {return x -> this.evaluate(x);}
    
    public static void main(String[] args) {
        RealPolynomial p = new RealPolynomial(7, -10.321, 2.22334, -1.25, 2);
        double root = p.NewtonRaphsonMethod(2, 10e-8, 10000, true);
        System.out.println("Full value of the root found with Newton-Raphson method: " + root);
        System.out.println("-------------------------------------------------------------------");
        root = p.HalleyMethod(2, 10e-8, 10000, true);
        System.out.println("Full value of the root found with Halley's method: " + root);
    }
} // Fin clase RealPolynomial

class RealMonomial extends RealPolynomial {
    private double mainCoef;
    
    public RealMonomial(double mc, int d) {
        super(monomialArray(mc, d));
        this.mainCoef = mc;
    }
    
    public RealMonomial(double number) {this(number, 0);}

    public double getMainCoef() {return this.mainCoef;}
    
    public static double[] monomialArray(double mc, int d) {
        if (mc == 0) return new double[] {0};
        double[] coefArray = new double[d+1];
        for (int i = 0; i < d+1; i++) {
            if (i == d) coefArray[i] = mc;
            else coefArray[i] = 0;
        }
        return coefArray;
    }
    
    @Override
    public RealPolynomial sum(RealPolynomial p) {
        p = p.castToMonomial();
        if (p instanceof RealMonomial && p.getDegree() == this.getDegree()) return new RealMonomial(this.mainCoef + ((RealMonomial) p).mainCoef, this.getDegree());
        
        double[] resultCoef = new double[Math.max(this.getDegree(), p.getDegree())+1];
        for (int i = 0; i < resultCoef.length; i++) {
            if (i == this.getDegree()) resultCoef[i] = this.mainCoef + p.getCoefficient(i);
            else resultCoef[i] = p.getCoefficient(i);
        }
        return new RealPolynomial(resultCoef).castToMonomial();
    }
    
    @Override
    public RealPolynomial mult(RealPolynomial p) {
        p = p.castToMonomial();
        if (p instanceof RealMonomial) return new RealMonomial(this.mainCoef * ((RealMonomial) p).mainCoef, this.getDegree() + p.getDegree());
        int monomialDegree = this.getDegree();
        double[] resultCoef = new double[p.getDegree() + monomialDegree + 1];
        
        for (int i = 0; i < resultCoef.length; i++) {
            if (i < monomialDegree) resultCoef[i] = 0;
            else resultCoef[i] = p.getCoefficient(i - monomialDegree) * this.mainCoef;
        }
        return new RealPolynomial(resultCoef);
    }
    
    @Override
    public RealPolynomial diff() {
        return this.getDegree() == 0 ? new RealMonomial(0, 0) : new RealMonomial(this.getDegree() * this.mainCoef, this.getDegree() - 1);
    }
}
