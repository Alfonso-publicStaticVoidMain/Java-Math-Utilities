package mainpackage;

import java.util.function.Function;

public class RealMatrix {
    
    private double[][] matrix;
    private int rows;
    private int cols;
    
    public RealMatrix(){
        this.matrix = new double[0][0];
        this.rows = 0;
        this.cols = 0;
    }
    
    public RealMatrix(double[][] matrix) {
        if (isMatrix(matrix)) {
            this.matrix = matrix;
            this.rows = matrix.length;
            this.cols = matrix[0].length;
        } else {
            this.matrix = new double[0][0];
            this.rows = 0;
            this.cols = 0;
        }
    }
    
    public RealMatrix(int numRows, int numCols) {
        this.matrix = new double[numRows][numCols];
        this.rows = numRows;
        this.cols = numCols;
    }

    public double[][] getMatrix() {return this.matrix;}

    public int getRows() {return this.rows;}

    public int getCols() {return this.cols;}
    
    
    
    /*
    * Returns true if the double[][] array is a matrix,
    * ie, if all of its entries are double[] arrays
    * of the same length, false otherwise
    * Returns false if the array is empty.
    */
    public static boolean isMatrix(double[][] matrix) {
        if (matrix.length == 0) return false;
        if (matrix.length == 1) return true;
        int expectedLength = matrix[0].length;
        for (int i = 1; i < matrix.length; i++) {
            if (matrix[i].length != expectedLength) return false;
        }
        return true;
    }
    
    /*
    * Returns true if the double[][] is a square matrix,
    * ie, if its a matrix and its number of columns is
    * equal to its number of rows, false otherwise.
    */
    public static boolean isSquareMatrix(double[][] matrix) {return isMatrix(matrix) && matrix.length == matrix[0].length;}
    public boolean isSquareMatrix() {return this.matrix.length == this.matrix[0].length;}
    
    public RealMatrix minor(int rowToSkip, int colToSkip) {return new RealMatrix(minor(this.matrix, rowToSkip, colToSkip));}
    
    public static double[][] minor(double[][] matrix, int rowToSkip, int colToSkip) {
        double[][] smallMatrix = new double[matrix.length - 1][matrix.length - 1];
        for (int row = 0, rowSmallMatrix = 0; row < matrix.length; row++) {
            for (int col = 0, colSmallMatrix = 0; col < matrix.length; col++) {
                if (rowToSkip != row && colToSkip != col) {
                    smallMatrix[rowSmallMatrix][colSmallMatrix] = matrix[row][col];
                    colSmallMatrix++;
                }
            } if (rowToSkip != row) rowSmallMatrix++;
        }
        return smallMatrix;
    }
    
    //Calculates the mathematical determinant of the matrix
    public double det() {
        if (!this.isSquareMatrix()) return Double.NaN;
        return det(this.matrix);
    }
    
    public static double det(double[][] matrix) {
        switch (matrix.length) {
            case 1 -> {return matrix[0][0];}
            case 2 -> {return matrix[0][0] * matrix[1][1] - matrix[1][0] * matrix[0][1];}
            default -> {
                double determinant = 0;
                for (int colToSkip = 0; colToSkip < matrix.length; colToSkip++) {
                    determinant += Math.pow(-1, colToSkip) * matrix[0][colToSkip] * det(minor(matrix, 0, colToSkip));
                }
                return determinant;
            }
        }
    }
    
    /*
    * Calculates the adjoint matrix, in which each element is the
    * determinant of its associated minor matrix.
    */
    public RealMatrix adjoint() {
        if (!this.isSquareMatrix()) return new RealMatrix();
        return new RealMatrix(adjoint(this.matrix));
    }
    
    public static double[][] adjoint(double[][] matrix) {
        if (matrix.length == 1) return matrix;
        double[][] adjointMatrix = new double[matrix.length][matrix.length];
        for (int row = 0; row < matrix.length; row++) for (int col = 0; col < matrix.length; col++) adjointMatrix[row][col] = det(minor(matrix, row, col));
        return adjointMatrix;
    }
    
    public RealMatrix inverse() {
        if (Math.abs(this.det()) < 1e-10) return new RealMatrix();
        return this.adjoint().scalarMult(1/this.det());
    }
    
    // Sums the A matrix to [this].
    public RealMatrix sum(RealMatrix A) {
        if (!(this.rows == A.rows && this.cols == A.cols)) return new RealMatrix();
        double[][] result = new double[this.rows][this.cols];
        for (int row = 0; row < this.rows; row++) for (int col = 0; col < this.cols; col++) result[row][col] = this.matrix[row][col] + A.matrix[row][col];
        return new RealMatrix(result);
    }
    
    // Invers the sign of each element of the matrix.
    public RealMatrix invertSign() {return this.scalarMult(-1);}
    
    // Multiples each element of the matrix by a real number
    public RealMatrix scalarMult(double d) {
        double[][] result = new double[this.rows][this.cols];
        for (int row = 0; row < this.rows; row++) for (int col = 0; col < this.cols; col++) result[row][col] = d * this.matrix[row][col];
        return new RealMatrix(result);
    }
    
    // Calculates the transpose matrix, switching rows with columns.
    public RealMatrix transpose() {
        double[][] result = new double[this.cols][this.rows];
        for (int row = 0; row < this.rows; row++) {
            for (int col = 0; col < this.cols; col++) {
                result[col][row] = this.matrix[row][col];
            }
        }
        return new RealMatrix(result);
    }
    
    // Returns the row in the specified position as a double[] array
    public double[] getRow(int row) {
        return this.matrix[row];
//        double[] result = new double[this.cols];
//        for (int i = 0; i < this.cols; i++) result[i] = this.matrix[row][i];
//        return result;
    }
    
    // Returns the row in the specified position as a row matrix
    public RealMatrix getRowAsMatrix(int row) {
        return rowVector(this.getRow(row));
    }
    
    // Returns the column in the specified position as a double[] array
    // Works properly
    public double[] getCol(int col) {
        double[] result = new double[this.rows];
        for (int i = 0; i < this.rows; i++) result[i] = this.matrix[i][col];
        return result;
    }
    
    // Returns the column in the specified position as column matrix
    public RealMatrix getColAsMatrix(int col) {
        return colVector(this.getCol(col));
    }
    
    /*
    * Multiplies the two matrices.
    * If dimensions aren't compatible, an empty matrix is returned.
    */
    public RealMatrix mult(RealMatrix A) {
        if (this.cols != A.rows) return new RealMatrix();
        double[][] result = new double[this.rows][A.cols];
        for (int row = 0; row < this.rows; row++) {
            for (int col = 0; col < A.cols; col++) {
                result[row][col] = CalcUtil.scalarProduct(this.getRow(row), A.getCol(col));
            }
        }
        return new RealMatrix(result);
    }
    
    // Passes a double[] array to a row matrix
    public static RealMatrix rowVector(double[] vector) {
        double[][] result = new double[1][vector.length];
        for (int i = 0; i < vector.length; i++) result[0][i] = vector[i];
        return new RealMatrix(result);
    }
    
    // Passes a double[] array to a column matrix
    public static RealMatrix colVector(double[] vector) {
        double[][] result = new double[vector.length][1];
        for (int i = 0; i < vector.length; i++) result[i][0] = vector[i];
        return new RealMatrix(result);
    }
    
    public double conjugateProduct(double[] x, double[] y) {
        return rowVector(x).mult(this).mult(colVector(y)).matrix[0][0];
    }
    
    public double conjugateProduct(double[] x) {
        return rowVector(x).mult(this).mult(colVector(x)).matrix[0][0];
    }
    
    // Returns a double[] array with the elements of the diagonal of the matrix
    public double[] getDiagonal() {
        int diagLength = Math.min(this.rows, this.cols);
        double[] result = new double[diagLength];
        for (int i = 0; i < diagLength; i++) result[i] = this.matrix[i][i];
        return result;
    }
    
    public boolean isLowerTriang() {
        for (int row = 1; row < this.rows; row++) {
            for (int col = 0; col < Math.min(row, this.cols); col++) {
                if (this.matrix[row][col] != 0) return false;
            }
        }
        return true;
    }
    
    public boolean isUpperTriang() {
        for (int col = 1; col < this.rows; col++) {
            for (int row = 0; row < Math.min(col, this.cols); row++) {
                if (this.matrix[row][col] != 0) return false;
            }
        }
        return true;
    }
    
    public static RealMatrix GaussMethod(boolean lower) {
        return new RealMatrix(); // TO DO
    }
    
    public double[] applyToVector(double[] x) {return this.mult(colVector(x)).getCol(0);}
    
    public Function<double[], double[]> toFunction() {return x -> this.applyToVector(x);}
    
    public void printMatrix() {
        double[][] A = this.matrix;
        for (int row = 0; row < this.rows; row++) {
            System.out.println(CalcUtil.vectorToString(A[row]));
        }
    }
    
    public static void main(String args[]) {
        double[][] matrix = new double[][] {
            {1, 0, 0, 0},
            {0, 0.25, 0, 0},
            {0, 0, 0.5, 0},
            {0, 0, 0, 1}
        };
        System.out.println(det(matrix));
    }
}
